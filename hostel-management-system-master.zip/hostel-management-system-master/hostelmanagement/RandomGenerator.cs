﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace hostelmanagement
{
    class RandomGenerator
    {
        internal object RandomPassword(int p)
        {
            throw new NotImplementedException();
        }

        internal object RandomString()
        {
            throw new NotImplementedException();
        }
    }
}
