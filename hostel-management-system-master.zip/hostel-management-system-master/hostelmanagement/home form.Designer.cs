﻿namespace hostelmanagement
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.rOOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uNIVERSITYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDDUNIVERSITYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWUNIVERSITYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTUDENTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEGISTRATIONFORMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWSTUDENTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rOOMSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDDROOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWROOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rOOMOCCUPIEDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rOOMSNOTOCCUPIEDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lOGOUTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(798, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 13);
            this.label6.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Copperplate Gothic Bold", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(305, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(409, 33);
            this.label8.TabIndex = 9;
            this.label8.Text = "ACOMODATION SYSTEM";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rOOMToolStripMenuItem,
            this.uNIVERSITYToolStripMenuItem,
            this.sTUDENTToolStripMenuItem,
            this.rOOMSToolStripMenuItem,
            this.lOGOUTToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1030, 24);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // rOOMToolStripMenuItem
            // 
            this.rOOMToolStripMenuItem.Name = "rOOMToolStripMenuItem";
            this.rOOMToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.rOOMToolStripMenuItem.Text = "HOME";
            this.rOOMToolStripMenuItem.Click += new System.EventHandler(this.rOOMToolStripMenuItem_Click);
            // 
            // uNIVERSITYToolStripMenuItem
            // 
            this.uNIVERSITYToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDUNIVERSITYToolStripMenuItem,
            this.vIEWUNIVERSITYToolStripMenuItem});
            this.uNIVERSITYToolStripMenuItem.Name = "uNIVERSITYToolStripMenuItem";
            this.uNIVERSITYToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.uNIVERSITYToolStripMenuItem.Text = "UNIVERSITY";
            // 
            // aDDUNIVERSITYToolStripMenuItem
            // 
            this.aDDUNIVERSITYToolStripMenuItem.Name = "aDDUNIVERSITYToolStripMenuItem";
            this.aDDUNIVERSITYToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.aDDUNIVERSITYToolStripMenuItem.Text = "ADD UNIVERSITY";
            this.aDDUNIVERSITYToolStripMenuItem.Click += new System.EventHandler(this.aDDUNIVERSITYToolStripMenuItem_Click);
            // 
            // vIEWUNIVERSITYToolStripMenuItem
            // 
            this.vIEWUNIVERSITYToolStripMenuItem.Name = "vIEWUNIVERSITYToolStripMenuItem";
            this.vIEWUNIVERSITYToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.vIEWUNIVERSITYToolStripMenuItem.Text = "VIEW UNIVERSITY";
            this.vIEWUNIVERSITYToolStripMenuItem.Click += new System.EventHandler(this.vIEWUNIVERSITYToolStripMenuItem_Click);
            // 
            // sTUDENTToolStripMenuItem
            // 
            this.sTUDENTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rEGISTRATIONFORMToolStripMenuItem,
            this.vIEWSTUDENTSToolStripMenuItem});
            this.sTUDENTToolStripMenuItem.Name = "sTUDENTToolStripMenuItem";
            this.sTUDENTToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.sTUDENTToolStripMenuItem.Text = "STUDENT";
            this.sTUDENTToolStripMenuItem.Click += new System.EventHandler(this.sTUDENTToolStripMenuItem_Click);
            // 
            // rEGISTRATIONFORMToolStripMenuItem
            // 
            this.rEGISTRATIONFORMToolStripMenuItem.Name = "rEGISTRATIONFORMToolStripMenuItem";
            this.rEGISTRATIONFORMToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.rEGISTRATIONFORMToolStripMenuItem.Text = "REGISTRATION FORM";
            this.rEGISTRATIONFORMToolStripMenuItem.Click += new System.EventHandler(this.rEGISTRATIONFORMToolStripMenuItem_Click);
            // 
            // vIEWSTUDENTSToolStripMenuItem
            // 
            this.vIEWSTUDENTSToolStripMenuItem.Name = "vIEWSTUDENTSToolStripMenuItem";
            this.vIEWSTUDENTSToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.vIEWSTUDENTSToolStripMenuItem.Text = "VIEW STUDENTS";
            this.vIEWSTUDENTSToolStripMenuItem.Click += new System.EventHandler(this.vIEWSTUDENTSToolStripMenuItem_Click);
            // 
            // rOOMSToolStripMenuItem
            // 
            this.rOOMSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDROOMToolStripMenuItem,
            this.vIEWROOMToolStripMenuItem});
            this.rOOMSToolStripMenuItem.Name = "rOOMSToolStripMenuItem";
            this.rOOMSToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.rOOMSToolStripMenuItem.Text = "ROOMS";
            // 
            // aDDROOMToolStripMenuItem
            // 
            this.aDDROOMToolStripMenuItem.Name = "aDDROOMToolStripMenuItem";
            this.aDDROOMToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.aDDROOMToolStripMenuItem.Text = "ADD ROOM";
            this.aDDROOMToolStripMenuItem.Click += new System.EventHandler(this.aDDROOMToolStripMenuItem_Click);
            // 
            // vIEWROOMToolStripMenuItem
            // 
            this.vIEWROOMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rOOMOCCUPIEDToolStripMenuItem,
            this.rOOMSNOTOCCUPIEDToolStripMenuItem});
            this.vIEWROOMToolStripMenuItem.Name = "vIEWROOMToolStripMenuItem";
            this.vIEWROOMToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.vIEWROOMToolStripMenuItem.Text = "VIEW ROOM";
            this.vIEWROOMToolStripMenuItem.Click += new System.EventHandler(this.vIEWROOMToolStripMenuItem_Click);
            // 
            // rOOMOCCUPIEDToolStripMenuItem
            // 
            this.rOOMOCCUPIEDToolStripMenuItem.Name = "rOOMOCCUPIEDToolStripMenuItem";
            this.rOOMOCCUPIEDToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.rOOMOCCUPIEDToolStripMenuItem.Text = "ROOM OCCUPIED";
            this.rOOMOCCUPIEDToolStripMenuItem.Click += new System.EventHandler(this.rOOMOCCUPIEDToolStripMenuItem_Click);
            // 
            // rOOMSNOTOCCUPIEDToolStripMenuItem
            // 
            this.rOOMSNOTOCCUPIEDToolStripMenuItem.Name = "rOOMSNOTOCCUPIEDToolStripMenuItem";
            this.rOOMSNOTOCCUPIEDToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.rOOMSNOTOCCUPIEDToolStripMenuItem.Text = "ROOMS NOT OCCUPIED";
            this.rOOMSNOTOCCUPIEDToolStripMenuItem.Click += new System.EventHandler(this.rOOMSNOTOCCUPIEDToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Location = new System.Drawing.Point(0, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1030, 71);
            this.panel1.TabIndex = 14;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = global::hostelmanagement.Properties.Resources.house1;
            this.pictureBox1.Location = new System.Drawing.Point(3, 97);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1024, 472);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lOGOUTToolStripMenuItem
            // 
            this.lOGOUTToolStripMenuItem.Name = "lOGOUTToolStripMenuItem";
            this.lOGOUTToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.lOGOUTToolStripMenuItem.Text = "LOG OUT";
            this.lOGOUTToolStripMenuItem.Click += new System.EventHandler(this.lOGOUTToolStripMenuItem_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(121)))), ((int)(((byte)(121)))));
            this.ClientSize = new System.Drawing.Size(1030, 570);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.ShowInTaskbar = false;
            this.Text = "Form2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem rOOMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uNIVERSITYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDDUNIVERSITYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWUNIVERSITYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTUDENTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEGISTRATIONFORMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWSTUDENTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rOOMSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDDROOMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWROOMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rOOMOCCUPIEDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rOOMSNOTOCCUPIEDToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem lOGOUTToolStripMenuItem;
    }
}